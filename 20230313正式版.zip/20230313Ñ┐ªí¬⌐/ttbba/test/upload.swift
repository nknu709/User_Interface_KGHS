//
//  upload.swift
//  test
//
//  Created by 709＠nknu on 2022/11/8.
//

import UIKit

class upload: UIViewController {

    @IBAction func Tostylechoose1(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_stylechoose1", sender:self)
    }
    
    
    @IBAction func UnWind1(for segue :UIStoryboardSegue){
        print("unwind...")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
