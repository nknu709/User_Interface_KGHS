//
//  dish.swift
//  test
//
//  Created by 709＠nknu on 2022/11/4.
//

import UIKit

class dish: UIViewController {

    @IBAction func Touploaddish(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_uploaddish", sender: self)
    }
    
    
    @IBAction func Totakepicturedish(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_takepicturedish", sender: self)
    }
    
    @IBAction func UnWind(for segue :UIStoryboardSegue){
        print("unwind...")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
