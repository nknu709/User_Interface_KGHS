//
//  translate5.swift
//  test
//
//  Created by 709＠nknu on 2023/1/2.
//

import UIKit

class translate5: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var searchear: UITextField!
    
    @IBOutlet weak var earlabel: UILabel!
    
    @IBAction func earpressed(_ sender: UIButton) {
        earlabel.text = searchear.text!
        print(searchear.text!)
        mydict["ear"] = "\(searchear.text!)"
    }
    
    @IBAction func Toeye5(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eye5", sender:self)
    }
    @IBAction func Toeyebrow5(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eyebrow5", sender:self)
    }
    @IBAction func Tonose5(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_nose5", sender:self)
    }
    @IBAction func Tomouth5(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_mouth5", sender:self)
    }
    @IBAction func Toshape5(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_shape5", sender:self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        searchear.delegate = self
        // Do any additional setup after loading the view.
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // 將文字以return按鈕送出
            return true
        }

}
