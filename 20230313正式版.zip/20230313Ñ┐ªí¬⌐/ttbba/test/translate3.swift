//
//  translate3.swift
//  test
//
//  Created by 709＠nknu on 2023/1/2.
//

import UIKit

class translate3: UIViewController, UITextFieldDelegate{

   
    @IBOutlet weak var searchnose: UITextField!
    
    @IBOutlet weak var noselabel: UILabel!
    
    @IBAction func nosepressed(_ sender: UIButton) {
        noselabel.text = searchnose.text!
        print(searchnose.text!)
        mydict["nose"] = "\(searchnose.text!)"
    }
    @IBAction func Toeye3(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eye3", sender:self)
    }
    
    @IBAction func Tomouth3(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_mouth3", sender:self)
    }
    
    @IBAction func Toshape3(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_shape3", sender:self)
    }
    @IBAction func Toear3(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_ear3", sender:self)
    }
    @IBAction func Toeyebrow3(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eyebrow3", sender:self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        searchnose.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // 將文字以return按鈕送出
            return true
        }
}
