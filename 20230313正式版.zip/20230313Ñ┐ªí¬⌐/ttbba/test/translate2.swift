//
//  translate2.swift
//  test
//
//  Created by 709＠nknu on 2023/1/2.
//

import UIKit

class translate2: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var searcheyebrow: UITextField!
    
    @IBOutlet weak var eyebrowlabel: UILabel!
    
    @IBAction func eyebrowpressed(_ sender: UIButton) {
        eyebrowlabel.text = searcheyebrow.text!
        print(searcheyebrow.text!)
        mydict["eyebrow"] = "\(searcheyebrow.text!)"
    }
    
    @IBAction func Toeye2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eye2", sender:self)
    }
    
    @IBAction func Tonose2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_nose2", sender:self)
    }
    @IBAction func Tomouth2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_mouth2", sender:self)
    }
    @IBAction func Toear2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_ear2", sender:self)
    }
    @IBAction func Toshape2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_shape2", sender:self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        searcheyebrow.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // 將文字以return按鈕送出
            return true
        }
}
