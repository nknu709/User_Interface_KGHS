//
//  translate4.swift
//  test
//
//  Created by 709＠nknu on 2023/1/2.
//

import UIKit

class translate4: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var searchmouth: UITextField!
    
    @IBOutlet weak var mouthlabel: UILabel!
    
    @IBAction func mouthpressed(_ sender: UIButton) {
        mouthlabel.text = searchmouth.text!
        print(searchmouth.text!)
        mydict["mouth"] = "\(searchmouth.text!)"
    }
    @IBAction func Toeye4(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eye4", sender:self)
    }
    @IBAction func Toeyebrow4(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eyebrow4", sender:self)
    }
    @IBAction func Tonose4(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_nose4", sender:self)
    }
    @IBAction func Toear4(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_ear4", sender:self)
    }
    @IBAction func Toshape4(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_shape4", sender:self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        searchmouth.delegate = self
        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // 將文字以return按鈕送出
            return true
        }
}
