//
//  translate.swift
//  test
//
//  Created by 709＠nknu on 2022/12/28.
//

import UIKit

class translate: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var eyelabel: UILabel!
    
    @IBOutlet weak var searcheye: UITextField!
    
    
    @IBAction func eyepressed(_ sender: UIButton) {
        eyelabel.text = searcheye.text!
        print(searcheye.text!)
        mydict["eye"] = "\(searcheye.text!)"
    }
    @IBAction func Toeyebrow(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_eyebrow", sender:self)
    }
    
    @IBAction func Tonose(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_nose", sender:self)
    }
    
    @IBAction func Tomouth(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_mouth", sender:self)
    }
    @IBAction func Toear(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_ear", sender:self)
    }
    @IBAction func Toshape(_ sender: UIButton) {
        self.performSegue(withIdentifier: "segue_shape", sender:self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searcheye.delegate = self
        
        /*let url = URL(string: "https://9076-140-127-80-193.jp.ngrok.io/js/index.js")!
         var request = URLRequest(url: url)
         request.httpMethod = "POST"
         request.setValue("application/json", forHTTPHeaderField: "Content-Type")
         let encoder = JSONEncoder()
         //var _:[String: String] = ["eye": "鳳眼", "eyebrow": "劍眉", "nose": "鷹鉤鼻", "mouth": "厚唇", "ear": "小耳", "shape": "圓臉"]
         let user = inputtext(eye: "鳳眼", eyebrow: "劍眉", nose: "鷹鉤鼻", mouth: "厚唇", ear: "小耳", shape: "圓臉")
         let data = try? encoder.encode(user)
         request.httpBody = data
         
         
         URLSession.shared.dataTask(with: request) { data, response, error in
         if let data {
         do {
         let decoder = JSONDecoder()
         let outputtext = try decoder.decode(outputtext.self, from: data)
         print(outputtext)
         } catch  {
         print(error)
         }
         }
         }.resume()
         }*/
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // 將文字以return按鈕送出
            return true
        }
    }
    
    
    
    func UnWindtranslate(for segue :UIStoryboardSegue)
    {
        print("unwind...")
    }
    
    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
}
