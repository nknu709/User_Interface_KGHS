//
//  file.swift
//  test
//
//  Created by 709＠nknu on 2022/12/4.
//

import Foundation

//給予後端圖片名稱與風格名稱
struct inputimg: Encodable {
    let filename: String
    let stylename: String
}

//後端給予前端圖片
struct outputimg1: Decodable {
    let result: String
}

struct inputtext: Encodable {
    let eye: String
    let eyebrow: String
    let nose: String
    let mouth: String
    let ear: String
    let shape: String
    //var textTrans = eye+" and "+eyebrow+" and "+nose+" and "+mouth+" and "+ear+" and "+shape
}

struct outputtext: Decodable {
    let textTrans_2: String
}

struct inputeng: Encodable {
    let textTrans_2: String
}

struct outputimg2: Decodable {
    let imgTrans: String
}
